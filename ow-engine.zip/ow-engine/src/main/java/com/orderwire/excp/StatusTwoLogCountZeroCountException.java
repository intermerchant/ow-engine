package com.orderwire.excp;

public class StatusTwoLogCountZeroCountException  extends Exception{
    //Parameterless Constructor
    public StatusTwoLogCountZeroCountException() {}

    //Constructor that accepts a message
    public StatusTwoLogCountZeroCountException(String message){
        super(message);
    }

}
